package com.sunny_dream.productos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sunny_dream.productos.model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long>{

    Producto findByNombre(Long id);

    List<Producto> findByStockLessThan(int stock);

}
